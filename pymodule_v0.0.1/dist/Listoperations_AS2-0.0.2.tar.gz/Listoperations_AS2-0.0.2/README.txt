This is a very simple list operation that takes either add, subtract, multiply or divide them and more functions for swap list and list techniques.
