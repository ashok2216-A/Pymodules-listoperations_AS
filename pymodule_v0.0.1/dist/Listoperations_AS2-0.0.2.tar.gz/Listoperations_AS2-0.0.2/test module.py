import listoperatorAS as lstop


print(dir(lstop))
a = [1,2,5,8,5,6,7,1,2,5]
print(lstop.checklst(urlist=a, checkwhat=5))