from pyexer import minnum, maxnum

print(minnum(5,2))
print(maxnum(5,2))